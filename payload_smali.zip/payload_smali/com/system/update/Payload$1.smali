.class Lcom/system/update/Payload$1;
.super Ljava/lang/Object;
.source "Payload.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/system/update/Payload;->onStartCommand(Landroid/content/Intent;II)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/system/update/Payload;


# direct methods
.method constructor <init>(Lcom/system/update/Payload;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 90
    iput-object p1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 92
    iget-object v0, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-virtual {v0}, Lcom/system/update/Payload;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Service Running"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 93
    return-void
.end method
